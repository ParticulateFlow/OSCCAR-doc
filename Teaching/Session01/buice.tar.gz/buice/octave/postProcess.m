clear all
close all
clc

%% read measurement data
% available from http://www.grc.nasa.gov/WWW/wind/valid/buice/buice01/exp_data.tar.gz
%
% m__U%.xX ... mean flow velocity at x/H = X
%   the file contains two columns of normalized data
%       the coordinate y/H
%       the flow velocity U/Ub

dataPath = 'case8_2';

d00 = importdata([dataPath,'/m__U%.x-6']);
d01 = importdata([dataPath,'/m__U%.x03']);
d02 = importdata([dataPath,'/m__U%.x06']);
d03 = importdata([dataPath,'/m__U%.x14']);
d04 = importdata([dataPath,'/m__U%.x17']);
d05 = importdata([dataPath,'/m__U%.x20']);
d06 = importdata([dataPath,'/m__U%.x24']);
d07 = importdata([dataPath,'/m__U%.x27']);
d08 = importdata([dataPath,'/m__U%.x30']);
d09 = importdata([dataPath,'/m__U%.x34']);

d10 = importdata([dataPath,'/m__U%.x40']);
d11 = importdata([dataPath,'/m__U%.x47']);
d12 = importdata([dataPath,'/m__U%.x53']);
d13 = importdata([dataPath,'/m__U%.x60']);
d14 = importdata([dataPath,'/m__U%.x67']);
d15 = importdata([dataPath,'/m__U%.x74']);

%%

H = 0.591;
Ub = 65;

x00n = -6;
x01n = 3;
x02n = 6;
x03n = 14;
x04n = 17;
x05n = 20;
x06n = 24;
x07n = 27;
x08n = 30;
x09n = 34;

x10n = 40;
x11n = 47;
x12n = 53;
x13n = 60;
x14n = 67;
x15n = 74;

%% read sampled data
% set postTime to the time-step you want to analyze

simPath = '../postProcessing/sets';
postTime = '9250';

sl01 = importdata([simPath,'/',postTime,'/sl1_U.xy']);
sl02 = importdata([simPath,'/',postTime,'/sl2_U.xy']);
sl03 = importdata([simPath,'/',postTime,'/sl3_U.xy']);
sl04 = importdata([simPath,'/',postTime,'/sl4_U.xy']);
sl05 = importdata([simPath,'/',postTime,'/sl5_U.xy']);
sl06 = importdata([simPath,'/',postTime,'/sl6_U.xy']);
sl07 = importdata([simPath,'/',postTime,'/sl7_U.xy']);
sl08 = importdata([simPath,'/',postTime,'/sl8_U.xy']);

% x-coordinates of sampled line in meter
x01s = -0.0874;
x02s = 0.0384;
x03s = 0.0892;
x04s = 0.2022;
x05s = 0.2527;
x06s = 0.3036;
x07s = 0.4063;
x08s = 0.5094;

%%

figure(1)
hold off

plot(x00n+10*d00(:,2)/Ub, d00(:,1), 'k.')
hold on
grid on
plot(x01n+10*d01(:,end)/Ub, d01(:,1), 'b*')
plot(x02n+10*d02(:,end)/Ub, d02(:,1), 'r*')
plot(x03n+10*d03(:,end)/Ub, d03(:,1), 'm*')
plot(x04n+10*d04(:,end)/Ub, d04(:,1), 'g*')
plot(x05n+10*d05(:,end)/Ub, d05(:,1), 'c*')
plot(x06n+10*d06(:,end)/Ub, d06(:,1), 'k*')

plot(x07n+10*d07(:,end)/Ub, d07(:,1), 'bx')
plot(x08n+10*d08(:,end)/Ub, d08(:,1), 'rx')
plot(x09n+10*d09(:,end)/Ub, d09(:,1), 'mx')

plot(x10n+10*d10(:,end)/Ub, d10(:,1), 'gx')
plot(x11n+10*d11(:,end)/Ub, d11(:,1), 'cx')
plot(x12n+10*d12(:,end)/Ub, d12(:,1), 'kx')
plot(x13n+10*d13(:,end)/Ub, d13(:,1), 'bo')
plot(x14n+10*d14(:,end)/Ub, d14(:,1), 'ro')
plot(x15n+10*d15(:,end)/Ub, d15(:,1), 'mo')

xlim([-10 40])

xlabel('x / H + 10 U/Ub')
ylabel('y / H')
title('Measured data')

%%

figure(2)
hold off

plot(x01s/0.0254/H + 10*sl01(:,2)/0.3048/Ub, sl01(:,1)/0.0254/H, 'k')

hold on
grid on

plot(x02s/0.0254/H + 10*sl02(:,2)/0.3048/Ub, sl02(:,1)/0.0254/H, 'b')
plot(x03s/0.0254/H + 10*sl03(:,2)/0.3048/Ub, sl03(:,1)/0.0254/H, 'r')
plot(x04s/0.0254/H + 10*sl04(:,2)/0.3048/Ub, sl04(:,1)/0.0254/H, 'm')
plot(x05s/0.0254/H + 10*sl05(:,2)/0.3048/Ub, sl05(:,1)/0.0254/H, 'g')
plot(x06s/0.0254/H + 10*sl06(:,2)/0.3048/Ub, sl06(:,1)/0.0254/H, 'c')
plot(x07s/0.0254/H + 10*sl07(:,2)/0.3048/Ub, sl07(:,1)/0.0254/H, 'k')
plot(x08s/0.0254/H + 10*sl08(:,2)/0.3048/Ub, sl08(:,1)/0.0254/H, 'b')

plot(x00n+10*d00(:,end), d00(:,1), 'k.')
plot(x01n+10*d01(:,end), d01(:,1), 'b*')
plot(x02n+10*d02(:,end), d02(:,1), 'r*')
plot(x03n+10*d03(:,end), d03(:,1), 'm*')
plot(x04n+10*d04(:,end), d04(:,1), 'g*')
plot(x05n+10*d05(:,end), d05(:,1), 'c*')

plot(x07n+10*d07(:,end), d07(:,1), 'k*')
plot(x09n+10*d09(:,end), d09(:,1), 'bx')


xlim([-10, 40])




xs = [x01s, x02s, x03s, x04s, x05s, x06s, x07s, x08s];


legendString = {};

for i=1:length(xs)
    legendString{i} = ['x/H = ',num2str(xs(i))];
end

xlabel('x / H + 10 U/Ub')
ylabel('y / H')
title('Sampled data from simulation and measured data')

legend(legendString,'location','SouthWest')
